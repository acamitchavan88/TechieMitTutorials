/**
 * @author #TechieMit
 * Topic :Main Method Overloading in Java
 */
package com.javabasics.demo.mainDemo;

public class MainMethodOverloading {

	public static void main(String[] args) {
		
		System.out.println("JVM main method of class MainMethodOverloading");
		// Integer Array 
		int intArray[ ]=new int[4];
		// Float Array 
		float floatArray[ ]=new float[4];
		// Double  Array 
		double  doubleArray[ ]=new double[4];
 
		//Overloaded call given to int Array
		main(intArray);
		//Overloaded call given to  2 argument array
		main(floatArray);
		
		//Overloaded call given to float Array
				main(floatArray,doubleArray);
	}
	
	// Method overloading taking integer array as parameter
	public static void main(int [] intArray)
	{

		System.out.println("Into Overloaded  Integer array main method ");
	}
	// Method overloading taking integer array as parameter
	public static void main(float [] floatArray)
	{
		System.out.println("Into Overloaded  float[] main method ");

	}
	// Method overloading taking integer array as parameter
		public static void main(float [] s,double[]str)
		{
			System.out.println("Into Overloaded  2 arguments main method ");

		}

}
